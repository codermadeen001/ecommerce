

<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"]=="GET"){

    if(!isset($_GET['id'])){
        //echo('id not Set');
        exit();
    }
    $id=$_GET['id'];
    if($id===NULL){
        echo('id not Set');
        exit();
    }


        
    $sql1="SELECT*FROM products WHERE id='$id'";
    $result1=$conn->query($sql1);
    if($result1->num_rows<1){
       header('location:checkProducts.php');
        exit();
    }

     $row1=$result1->fetch_assoc();
     $productName=$row1['productName'];
     $productDes=$row1['productDes'];
     $productPrice=$row1['productPrice'];
     $productQuantity=$row1['productQuantity'];
     $productId=$row1['productId'];
    $productImage=$row1['productImage'];

}
else{
     //post, update data
        $id=$_POST['id'];
        $ProductDes=$_POST['productDes'];
        $productPrice=$_POST['productPrice'];
        $productName=$_POST['productName'];
        $productQuantity=$_POST["productQuantity"];
       

        $value=$_POST["true"];


        if($value=="true"){

            $productImage = addslashes(file_get_contents($_FILES['image']['tmp_name']));
            // Insert data into database
            $sql = "UPDATE products  SET productImage='$productImage', productName='$productName', productDes='$ProductDes',productPrice='$productPrice', productQuantity='$productQuantity' WHERE id='$id'";
            if ($conn->query($sql) === TRUE) {
            echo $productName." updated successfully";
            header('location:checkProducts.php');
            exit;
           } else {
             echo "Error: " . $sql . "<br>" . $conn->error;
             exit;
                 }

            $conn->close();
              
           
        }else{
           
              $sql = "UPDATE products  SET productName='$productName', productDes='$ProductDes',productPrice='$productPrice', productQuantity='$productQuantity' WHERE id='$id'";
              if ($conn->query($sql) === TRUE) {
              echo $productName." updated successfully";
              header('location:checkProducts.php');
              exit;
             } else {
               echo "Error: " . $sql . "<br>" . $conn->error;
               exit;
                   }
  
              $conn->close();

              

        }

    }


?>



 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <style>
      

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Source Sans pro", sans-serif;
}

section{
    background-color: #f9f1f1;
    width: 100%;
    height: 100vh;
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-around;

}

.innercontainer2{
    border-radius: 15px;
    padding:  30px 50px;
    width: 420px;
    height: 560px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 4px 4px 30px rgb(255, 165, 0);
}
 
.innercontainer2 button{
    background-color: #111;
    margin: 5px ;
}
.innercontainer2 h3{
    font-size: 23px;
}
.innercontainer2 .add, button a{
    color:#fff;
    font-size: 18px;
    text-decoration: none;
}

form input{
    width: 270px;
    height: 25px;
    border-radius: 5px;
    border: 1px solid #3333;
    outline: none;
    margin:  0;
    padding-left: 20px;
    font-size: 18px;
}
form h3{
    color: #111;
    padding-top: 0px;
    font-size: 22px;
}
form p{
    color: #111;
    font-size: 20px;
    padding: 0px 0px;
}

form p input{
    width: 30px;
    height: 25px;
    margin-right: 5px;
}
form button{
    cursor: pointer;
    outline: none;
    border: none;
    width: 130px;
    height: 35px;
    margin-top: 5px;
    transition: .5s;
    border-radius: 7px;
}
form button:hover{
    background-color: rgb(255, 165, 0);
}
.image{
    display: flex;
    align-items: center;
    justify-content: space-around;

}
.image .radio{
    display:block;
    
}
.image .radio input{
    width: 20px;
    height: 25px;
    border-radius: 5px;
    border: 1px solid #3333;
    outline: none;
    margin-left:55px;
    padding-left: 20px;
    font-size: 18px;

}
.image p{
    display: flex;
    align-items: center;
    justify-content: right;

}
.txt{
    font-size:10px !important;

}



    </style>
<section>

<div class="innercontainer2">
    <h3>Update Products Details</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo$id?>">
        <P>Product Name</P>
        <input type="text" name="productName" required value="<?php echo$productName?>">
        <p>Product Description</p>
        <input type="text" name="productDes" required value="<?php echo$productDes?>">
        <P>Product Price</P>
        <input type="text" name="productPrice" required  value="<?php echo$productPrice?>">
        <P>Product Quantity</P>
        <input type="text" name="productQuantity" required value="<?php echo$productQuantity?>">

        <P>Product Image</P>
        <div class="image">
            <?php echo "<img style=' border-radius: 100%; height: 80px; width: 80px;' src='data:image/jpeg;base64," . base64_encode($row1['productImage']) . " '><br>";?>
            <input  type="file" name="image">
            <div class="radio">
            <p><b class="txt">update Image</b><input type="radio" name="true" id="" value="true"></p>
            <P><b class="txt">Don`t update Image</b><input type="radio" name="true" id="" value="false"></p>
            </div>
        </div>
        <button class="add" type="submit" id="popupButton2">Update</button>
        <button class="add" type="submit"><a href="checkProducts.php">Cancel</a></button>
    </form>
</div>
</section>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

/*





   $(document).ready(function() {
    $("#popupButton2").click(function (e) {
           e.preventDefault();
           var formData=new FormData();
           formData.append('image',$('input[name=image]')[0].files[0]);
           formData.append('productName',$('input[name=productName]').val());
           formData.append('id',$('input[name=id]').val());
           formData.append('productDes',$('input[name=productDes]').val());
           formData.append('productPrice',$('input[name=productPrice]').val());
           formData.append('productQuantity',$('input[name=productQuantity]').val());
           formData.append('true',$('input[name=true]').val());
           $.ajax({
               url: 'checkProducts_update.php',
               method: 'POST',
               data: formData,
               contentType:false,
               processData:false,
               success: function (result) {
                   alert(result);
                   window.location.href = 'checkproducts.php';
               }
           });
       });
   });

*/


</script>
</html>