<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admnPanel.css">
    <title>Document</title>
</head>

<body>

<?php 
session_start();
if(isset($_SESSION['userName'])){
  $userName=$_SESSION['userName']; 
  if($_SESSION['privilegde']==1){
    $userName=' Admn '.$_SESSION['userName'];
  }else{
    echo'Not Authorized to access this page';
    exit();
  }
   echo(' 
   <div id="popup" style="display: none;position: fixed; z-index: 9999;top: 30%;left: 10%;transform: translate(-50%, -50%);
   background-color: lightgreen; padding: 20px;padding-bottom: 80px; border-radius: 10px; width: 200px; height: 70px;">
       <p id="popupContent" style="color: #fff;font-size: 18px;"> You are interacting as '.$userName.' </p>
   </div>
   ');

   }

?>

    <div class="nav">
        <div class="logo">
            <img src="photos\IMG-20240222-WA0003.jpg">
            <h3>Cents` Online Shoppers</h3>
        </div>

        <div class="menu">
            <button type="button"id="btn" value="" onclick="fun()">Menu</button>
            <ul class="menuitems" id="menuitems">
                <li  class="active" ><a href="admnPanel.html">Admns` Panel</a></li>
                <li  class="no"><a href="checkUsers.php">Check Users</a></li>
                <li class="no"><a href="checkProducts.php">Check Products</a></li>
                <li  class="no"><a href="checkSales.php">Check Sales</a></li>
                <li  ><a href="index.php">Home</a></li>
            </ul>
        </div>
</div>

<section>
   
    
    <div class="container1">
        <a href="checkUsers.php"><button class="check" type="submit">Check Users</button></a>
        <a href="checkProducts.php"><button class="check" type="submit">Check products</button></a>
        <a href="checkSales.php"><button class="check" type="submit">Check sales</button></a>
    </div>

    <div class="container2">
    <div class="innercontainer1">
        <h3>Remove user</h3>
        <form action="removeUser.php" method="post">
            <input type="text" name="userName" id="" placeholder="Enter UserName" required>
            <button class="delete" type="submit" id="popupButton2">Delete</button>
        </form>
    </div>
    
    <div class="innercontainer2">
        <h3>Add Products</h3>
        <form action="addProducts.php" method="post" enctype="multipart/form-data"  id="addForm">
            <P>Product Name</P>
            <input type="text" name="productName" required id="productName">
            <p>Product Description</p>
            <input type="text" name="productDes" required id="productDes">
            <P>Product Price</P>
            <input type="text" name="productPrice" required id="productPrice">
            <P>Product Quantity</P>
            <input type="text" name="productQuantity" required id="productQuantity">
            <P>Product Image</P>
            <input type="file" name="image" id="image" required id="productImage">
            <p>Product Id</p>
            <input type="text" name="productId" required id="productId">
            <button class="add" type="submit" id="popupButton1">Upload</button>
        </form>
    </div>
</div>
</section>






<script src="shop.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>


    $(document).ready(function() {
       $("#popupButton1").click(function (e) {
           e.preventDefault();
           var formData=new FormData();
           formData.append('image',$('input[name=image]')[0].files[0]);
           formData.append('productName',$('input[name=productName]').val());
           formData.append('productDes',$('input[name=productDes]').val());
           formData.append('productPrice',$('input[name=productPrice]').val());
           formData.append('productQuantity',$('input[name=productQuantity]').val());
           formData.append('productId',$('input[name=productId]').val());
           $.ajax({
               url: 'addProducts.php',
               method: 'POST',
               data: formData,
               contentType:false,
               processData:false,
               success: function (result) {
                   alert(result);
               }
           });
       });
   });



   $(document).ready(function() {
       $("#popupButton2").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'removeUser.php',
               method: 'POST',
               data: {userName:$("input[name='userName']").val()},
               
               success: function (result) {
                   alert(result);
               }
           });
       });
   });



   $(document).ready(function() {
            if($("#popupContent").text() !=="  "){
                    $("#popup").fadeIn();
                    setTimeout(function(){
                    $("#popup").fadeOut("slow");
                    }, 6000);

            }

        });
</script>
</body>
</html>
<!--/html>




composer global require laravel/installer

laravel new project-name











    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="home.css">
    <title>Document</title>
</head>

<script>
        $(document).ready(function() {
            if($("#popupContent").text() !=="  "){
                    $("#popup").fadeIn();
                    setTimeout(function(){
                    $("#popup").fadeOut("slow");
                    }, 6000);

            }

        });
 
    </script>

<body>

<?php 
session_start();
if(isset($_SESSION['userName'])){
  $userName=$_SESSION['userName']; 
  if($_SESSION['privilegde']==1){
    $userName=' Admn '.$_SESSION['userName'];
  }
   echo(' 
   <div id="popup" style="display: none;position: fixed; z-index: 9999;top: 30%;left: 10%;transform: translate(-50%, -50%);
   background-color: lightgreen; padding: 20px;padding-bottom: 80px; border-radius: 10px; width: 200px; height: 70px;">
       <p id="popupContent" style="color: #fff;font-size: 18px;"> You are interacting as '.$userName.' </p>
   </div>
   ');

   }

?>