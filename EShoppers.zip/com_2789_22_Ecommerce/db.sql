CREATE database ecommerce;
use ecommerce;
CREATE TABLE login(
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL UNIQUE,
    userName VARCHAR(20)NOT NULL UNIQUE,
    email VARCHAR(30)NOT NULL UNIQUE,
    contact BIGINT(10)NOT NULL UNIQUE,
    password VARCHAR(30)NOT NULL,
    status INT(1)
);
INSERT INTO login(name, userName, email,contact, password, status) VALUES('Innocent Wanga','iCents','syeundainnocent@gmail.com',0756303470,'123456',0);



CREATE TABLE admn(
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL UNIQUE,
    userName VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(30)NOT NULL UNIQUE,
    contact BIGINT(10)NOT NULL UNIQUE,
    password VARCHAR(30)NOT NULL
);
INSERT INTO admn(name, userName, email,contact, password) VALUES('Innocent Wanga','iCents','syeundainnocent@gmail.com',0756303470,'123456');

CREATE TABLE products(
    id INT PRIMARY KEY AUTO_INCREMENT,
    productName VARCHAR(30) NOT NULL UNIQUE,
    productDes VARCHAR(30)NOT NULL UNIQUE,
    productPrice DECIMAL(10,2)NOT NULL,
    productQuantity BIGINT(10)NOT NULL,
    productImage LONGBLOB NOT NULL UNIQUE,
    productId INT(4) NOT NULL UNIQUE
);

CREATE TABLE cart(
    id INT PRIMARY KEY AUTO_INCREMENT,
    userName VARCHAR(30), 
    productName VARCHAR(30),
    productDes VARCHAR(30),
    productPrice DECIMAL(10,2),
    productQuantity BIGINT(10),
    productImage LONGBLOB ,
    productId INT(4) 
);


CREATE TABLE comments(
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(30),
    comments VARCHAR (200)
);


