<?php
if(!isset($_GET["id"])){ 
    header("Location:shop.php");
    exit(); 
}
$id=$_GET["id"];


session_start();
if(!isset($_SESSION['userName'])){
  echo("Sorry, please Login to shop");
  exit();
}

if($_SESSION['privilegde']==1){
  echo("Sorry you can`t shop, you are an Admn: ");
  exit();
}

$userName=$_SESSION['userName'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql1="SELECT*FROM products WHERE id='$id'";
$result1=$conn->query($sql1);

$row1=$result1->fetch_assoc();
$productName=$row1['productName'];
$productDes=$row1['productDes'];
$productPrice=$row1['productPrice'];
$productQuantity=$row1['productQuantity'];
$productId=$row1['productId'];
$productImage=$row1['productImage'];;

if($row1['productQuantity']<1){
    echo $productName.' is out of stoke';
    exit();
}


$newProductQuantity=$productQuantity-1;
$sql2="UPDATE products SET productQuantity='$newProductQuantity' WHERE productId='$productId'";
$result2=$conn->query($sql2);


$sql3="SELECT*FROM cart WHERE productId='$productId' && userName='$userName'";
$result3=$conn->query($sql3);
if($result3->num_rows<1){
    $ProductQuantity=1;

    $insertSql = "INSERT INTO cart (productImage, productName, productDes,ProductQuantity,productPrice,productId,userName) VALUES (?, ?,?,?,?, ?,?)";
    $stmt = $conn->prepare($insertSql);
    $null = NULL; // Needed for binding BLOB data
    $stmt->bind_param("bssiiis", $null, $productName, $productDes,$ProductQuantity,$productPrice,$productId,$userName);
    $stmt->send_long_data(0, $productImage);
  
    if ($stmt->execute()) {
      echo $productName.' Added to cart';
    } else {
      echo "Error inserting image: " . $stmt->error;
    }
    $stmt->close();
    exit();
}else{

    $sql4="SELECT*FROM cart WHERE productId='$productId'&& userName='$userName'";
    $result4=$conn->query($sql4);
    $row4=$result4->fetch_assoc();
    $productQuantity=$row4['productQuantity'];
   
   $newProductQuantity=$productQuantity+1;   
   $newProductPrice=$productPrice*$newProductQuantity;  

   $sql5="UPDATE cart SET productQuantity='$newProductQuantity' WHERE productId='$productId'&& userName='$userName'";
   $result5=$conn->query($sql5);

   $sql6="UPDATE cart SET productPrice='$newProductPrice' WHERE productId='$productId'&& userName='$userName'";
   $result6=$conn->query($sql6);

   if ($result5&&$result6===TRUE) {
    echo $productName.' Added to cart';
  } else {
    echo "Error inserting PRODUCT: " ;
  }


}


$conn->close();

