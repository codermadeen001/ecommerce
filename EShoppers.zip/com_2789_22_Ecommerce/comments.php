<?php
$email=$_POST['email'];
$comments=$_POST["comment"];


$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}

$sql="INSERT INTO comments(email,comments) VALUES('$email','$comments')";
$msqli=$conn->query($sql);

if($msqli===TRUE){
    echo('Coments recieved successful');
}else{
    echo'Erro '.sql.'<br>'.$conn->error;
}

$conn->close();
exit;