<?php
if(isset($_GET["id"])){  
$id=$_GET["id"];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

$sql= "SELECT*FROM login WHERE id='$id'" ;
$result=$conn->query($sql);
$row=$result->fetch_assoc();
$status=$row['status'];
$userName=$row['userName'];
$email=$row['email'];


$sql1= "DELETE FROM login WHERE id='$id'" ;
$result1=$conn->query($sql1);
echo($userName.' is deleated ');


$to = $email;
$subject = "Account Deletion";
$message = "This is to inform you ".$userName.", that your account for Cents` Online Shoppers \n has beeen deleted.";
$headers = "From: syeundainnocent@gmail.com" . "\r\n" .
           "Reply-To: syeundainnocent@gmail.com" . "\r\n" .
           "X-Mailer: PHP/" . phpversion();
mail($to, $subject, $message, $headers);
exit();

}else{
    echo 'id not set';
}
    
   


