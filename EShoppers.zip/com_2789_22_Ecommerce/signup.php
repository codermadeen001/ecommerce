<?php
$userName=$_POST['userName'];

$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
$contact=$_POST['contact'];
$status=0;

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass='';



$conn=new mysqli($hostname,$username, $pass, $database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}


$nameCheck= "SELECT*FROM login WHERE name='$name'" ;
$result1=$conn->query($nameCheck);
if($result1->num_rows>0){
    echo '  '.$name.' Already Registered';
    exit();
}


$userName_check= "SELECT*FROM login WHERE userName='$userName'" ;
$result2=$conn->query($userName_check);
if($result2->num_rows>0){
    echo ' sorry '.$userName.' is taken';
    exit();
}

$email_check= "SELECT*FROM login WHERE email='$email'" ;
$result3=$conn->query($email_check);
if($result3->num_rows>0){
    echo 'This email '.$email.' is already registered';
    exit();
}

$contact_check= "SELECT*FROM login WHERE contact='$contact'" ;
$result4=$conn->query($contact_check);
if($result4->num_rows>0){
    echo 'This contact '.$contact.' is already registered';
    exit();
}


$sql="INSERT INTO login(name, userName, email,contact, password, status) VALUES('$name','$userName','$email','$contact','$password','$status')";
$msqli=$conn->query($sql);

if($msqli===TRUE){
    echo "Registration is successful";
}else{
    echo'Erro '.sql.'<br>'.$conn->error;
}

$conn->close();
exit;
?>