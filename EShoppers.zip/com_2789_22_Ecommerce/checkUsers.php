<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="container mv-5">
        <h2>List of clients</h2>
        <a href="checkUsers_create.php" class="btn btn-primary" role="button">New User </a>
        <br>
        <table class="table">
           <thead>
           <tr>
                <td>Name</td>
                <td>userName</td>
                <td>Contact</td>
                <td>Email</td>
                <td>Action</td>
            </tr>
            </thead>

            <tbody>
            <?php
            $hostname='localhost';
            $username='root';
            $database='ecommerce';
            $pass=NULL;

            $conn=new mysqli($hostname,$username, $pass,$database);
            if($conn->connect_error){
              die('Connection failed: '.$conn->connect_error);
            }

            $sql1= "SELECT*FROM login" ;
            $result1=$conn->query($sql1);
            if($result1->num_rows<1){
               echo'No registered users';
               exit();
            }

            while ($row=$result1->fetch_assoc()){
             echo("
             <tr>
                <td>$row[name]</td>
                <td>$row[userName]</td>
                <td>$row[contact]</td>
                <td>$row[email]</td>
                <td>
                <a href='checkUsers_unsuspend.php?id=$row[id]' class='btn btn-success btn-sm' id='unsus'>Unsuspend</a>
                <a href='checkUsers_suspend.php?id=$row[id]' class='btn btn-warning btn-sm' id='sus'>Suspend</a>
                <a href='checkUsers_del.php?id=$row[id]' class='btn btn-danger btn-sm' id='deleteBtn'>Delete</a>
                </td>
            </tr>
            
             ");
           }
         
           ?>
        </tbody>
        </table>
        </div>
        <a style="margin-left: 130px;"  href='admnPanel.php' class='btn btn-primary btn-sm'>admnPanel</a>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click','#deleteBtn',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'checkUsers_del.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });

    $(document).ready(function() {
        $(document).on('click','#sus',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'checkUsers_suspend.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });


    $(document).ready(function() {
        $(document).on('click','#unsus',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'checkUsers_unsuspend.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });
</script>
</html>