<?php
$userName=$_POST["userName"];



$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}



$sql1="SELECT*FROM login WHERE userName='$userName'";
$result1=$conn->query($sql1);

if($result1->num_rows<1){
    echo $userName.' not found';
    exit();
}else{
    $sql2="DELETE FROM login WHERE userName='$userName'";
    $result2=$conn->query($sql2);
    if($result2===TRUE){
        echo $userName." Deleted successfully";
        exit();
    }else{
        echo "Sorry, not added: " . $conn->error;
    }
}



$conn->close();
exit;