
<?php
//return response()->json(['result' => 'success']);
session_start();
if(!isset($_SESSION['userName'])){
    header("Location:index.html");
    exit();
}
$userName=$_SESSION['userName'];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass='';

$conn=new mysqli($hostname,$username, $pass, $database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}


$sql1= "SELECT*FROM cart WHERE userName='$userName'" ;
$result1=$conn->query($sql1);
if($result1->num_rows>0){
    while($row1=$result1->fetch_assoc()){
       $productId=$row1['productId'];
       $quantity=$row1['productQuantity'];

       $sql2="SELECT productQuantity FROM products WHERE productId='$productId'";
       $result2=$conn->query($sql2);
       $row2=$result2->fetch_assoc();
       $newProductQuantity=$row2['productQuantity']+$quantity;

       $sql3="UPDATE products SET productQuantity='$newProductQuantity' WHERE productId='$productId'";
       $result3=$conn->query($sql3);

       $sql4= "DELETE FROM cart WHERE productId='$productId' && userName='$userName' " ;
       $result4=$conn->query($sql4);
       
    }
   
    }

session_destroy();
header("Location:index.php");
$conn->close();
exit;
?>