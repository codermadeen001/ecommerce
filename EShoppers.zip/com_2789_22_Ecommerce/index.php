
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="home.css">
    <title>Document</title>
</head>

<script>
        $(document).ready(function() {
            if($("#popupContent").text() !=="  "){
                    $("#popup").fadeIn();
                    setTimeout(function(){
                    $("#popup").fadeOut("slow");
                    }, 6000);

            }

        });
 
    </script>

<body>

<?php 
session_start();
if(isset($_SESSION['userName'])){
  $userName=$_SESSION['userName']; 
  if($_SESSION['privilegde']==1){
    $userName=' Admn '.$_SESSION['userName'];
  }
   echo(' 
   <div id="popup" style="display: none;position: fixed; z-index: 9999;top: 30%;left: 10%;transform: translate(-50%, -50%);
   background-color: lightgreen; padding: 20px;padding-bottom: 80px; border-radius: 10px; width: 200px; height: 70px;">
       <p id="popupContent" style="color: #fff;font-size: 18px;"> You are interacting as '.$userName.' </p>
   </div>
   ');

   }

?>

    <div class="navb">
        <div class="logo">
            <img src="photos\IMG-20240222-WA0003.jpg">
            <h3>Cents` Online Shoppers</h3>
        </div>
        <div class="menu">
            <button type="button"id="btn" value="" onclick="fun()">Menu</button>
            <ul class="menuitems" id="menuitems">
                <li  class="active" ><a href="index.php">Home</a>
                <ul><li><a href="#contact">Contact Us</a></li></ul>
                </li>
                <li><a href="shop1.php">Shop</a></li>
                <li  ><a href="checkout.php">Checkout</a></li>
            </ul>
        </div>
    </div>


        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="photos/IMG-20240225-WA0020.jpg" class="" alt="image1">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Happy Easter Holidays</h5>
                      <p>Get special offers, this Easter Season</p>
                    </div>
                </div>

                <div class="carousel-item ">
                    <img  src="photos/IMG.jpg" class="" alt="image0">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>  We Deal With All Items </h5>
                      <p>Ranging from phones, electronics, cloathings, furnitures etc</p>
                    </div>
                </div>


                <div class="carousel-item ">
                    <img  src="photos\IMG-20240225-WA0019.jpg" class="" alt="image0">
                    <div class="carousel-caption d-none d-md-block">
                      <h5 style="color: #111;">  Location </h5>
                      <p style="color: #111;">We are located at nambale town </p>
                    </div>
                </div>



                <div class="carousel-item">
                    <img  src="photos/IMG-20240225-WA0018.jpg" class="" alt="image2">
                        <div class="carousel-caption d-none d-md-block">
                          <h5>its` Christmass</h5>
                          <p>Yes everyday is like christmass because of our enjoyable discounts!</p>
                        </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
             <span class="carousel-control-next-icon" aria-hidden="true"></span>
             <span class="visually-hidden">Next</span>
            </button>
        </div>




    <div class="contact" id="contact">
        <div class="innercontact1">
            <h2>Contact Us </h2>
            <h3>+254111662566</h3>
        </div>
        <div class="innercontact2">
            <a href="">Fb</a>
            <a href="">Twitter</a>
            <a href="https://t.me/iCents">Telegram</a>
            <h6>syeundainnocent@gmail.com</h6>
            <form action="comments.php" method="post">
                <textarea name="comment" id="" cols="30" rows="1.5" placeholder="Comments/Complains/Querys"></textarea>
                <input type="email" name="email" id="" placeholder="email">
                <button type="submit" name="submit" id="popupButton">Submit</button>
            </form>
        </div>
    </div>
</body>
<script src="shop.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $("#popupButton").click(function (e) {
            e.preventDefault();
            $.ajax({
                url: 'comments.php',
                method: 'POST',
                data: {comment:$("textarea[name='comment']").val(), email:$("input[name='email']").val() },
                
                success: function (result) {
                    alert(result);
                }
            });
        });
    });
</script>

</script>
<style>
ul ul {
    display: none!important;
    position: absolute;
    background-color: #111;
    transform: translateY(21px) !important;
    padding: 10px;
    list-style: none;
    width: 200px !important;
    z-index: 1000;
  }
  ul ul a{
    font-size: 18px !important;
  }
  li:hover > ul {
    display: block !important;
  }
.nav ul .active{
    background-color: rgb(255, 165, 0) ;
    padding: 20px;
    
}

</style>

</html>