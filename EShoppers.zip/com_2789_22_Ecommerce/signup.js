

        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            
            if (password == "" || confirmPassword == "") {
                alert("Please fill in all password fields.");
                return false;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match. Please re-enter your passwords.");
                return false;
            }

           
            return true;
        }



        

    
  const passwordInput = document.getElementById('password');
  const passwordToggle = document.getElementById('password-toggle');

  passwordToggle.addEventListener('click', function() {
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      passwordToggle.textContent = '(Hide)';
    } else {
      passwordInput.type = 'password';
      passwordToggle.textContent = '(Show)';
    }
  });



  const passwordInput2 = document.getElementById('confirmPassword');
  const passwordToggle2 = document.getElementById('password-togle');

  passwordToggle2.addEventListener('click', function() {
    if (passwordInput2.type === 'password') {
      passwordInput2.type = 'text';
      passwordToggle2.textContent = '(Hide)';
    } else {
      passwordInput2.type = 'password';
      passwordToggle2.textContent = '(Show)';
    }
  });

  
