
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecommerce";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Upload image
$productImage = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$productId = $_POST['productId'];
$productQuantity = $_POST['productQuantity'];
$productPrice = $_POST['productPrice'];
$productDes = $_POST['productDes'];
$productName = $_POST['productName'];


// Insert data into database
$sql = "INSERT INTO products (productName,productDes,productPrice, productQuantity, productId,productImage) VALUES ('$productName','$productDes','$productPrice','$productQuantity', '$productId', '$productImage')";
if ($conn->query($sql) === TRUE) {
    echo $productName ."  uploaded to database";
} else {
    echo "Sorry, not added: " . $conn->error;
}


$conn->close();
?>
