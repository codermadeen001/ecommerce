<?php
if(isset($_GET["id"])){  
$id=$_GET["id"];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);
if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

$sql1="SELECT*FROM cart WHERE id='$id'";
$result1=$conn->query($sql1);
$row1=$result1->fetch_assoc();
$productId=$row1['productId'];
$productQuantity=$row1['productQuantity'];
$productName=$row1['productName'];

$sql2="SELECT*FROM products WHERE productId='$productId'";
$result2=$conn->query($sql2);
$row2=$result2->fetch_assoc();
$newProductQuantity=$row2['productQuantity']+$productQuantity;
$sql3="UPDATE products SET productQuantity='$newProductQuantity' WHERE productId='$productId'";
$result3=$conn->query($sql3);

$sql4= "DELETE FROM cart WHERE id='$id'" ;
$result4=$conn->query($sql4);

echo('  '.$productQuantity.' '.$productName.' deleated from cart');

}else{
    echo 'id not set';
}


