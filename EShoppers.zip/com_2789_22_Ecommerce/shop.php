<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div class="d">dfghdf</div>
<?php 
session_start();
if(isset($_SESSION['userName'])&& $_SESSION['privilegde']==2){
    $userName=$_SESSION['userName']; 
    $sql="SELECT*FROM cart WHERE userName='$userName'";
    $result=$conn->query($sql);
    $amount=0;
    $quantity=0;
    if($result->num_rows>0){
        while ($row=$result->fetch_assoc()){
              $row['productQuantity'];
              $row['productPrice'];
          $quantity=$quantity+$row['productQuantity'];
          $amount=$amount+$row['productPrice'];
    }
}
if($amount>0){
   echo(" 
   <a href='checkout.php'> <div style='border-radius: 100%; cursor:pointer; position: fixed; z-index: 9999;top: 10%;left: 95%;transform: translate(-50%, -50%);
        background-color: lightgreen; padding: 35px; width: 120px; height: 120px;'>
            <p  style='font-weight: bold; color: #111;font-size: 20px; '>$quantity </p>
            <p style='color: rgb(255, 165, 0);font-size: 20px; padding-bottom:30px !important; font-weight: bold;'>$amount/=</p>
        </div></a>
        
        " );
}

   }

?>  <div class="main">
    <div class="container mv-5">
        <h2>List of Products</h2>
        <br>
        <table class="table">
           <thead>
           <tr>
                <td>Image</td>
                <td>Name</td>
                <td>Description</td>
                <td>Quantity</td>
                <td>Price</td>
                <td>Add to Cart</td>
            </tr>
            </thead>

            <tbody>
            <?php
            $sql1= "SELECT*FROM products WHERE productId>=13" ;
            $result1=$conn->query($sql1);
            if($result1->num_rows<1){
               echo'No products';
               
            }

            while ($row=$result1->fetch_assoc()){
             echo("
             <tr>
                <td><img style='border-radius: 100%;width: 100px; height: 100px;' src='data:image/jpeg;base64," . base64_encode($row['productImage']) . " '></td>
                <td>$row[productName]</td>
                <td>$row[productDes]</td>
                <td>$row[productQuantity]</td>
                <td>$row[productPrice]</td>
                <td>
                <a href='addToCart2.php?id=$row[id]'id='add' class='btn btn-primary btn-sm' style=' width:70px;'>Add </a>
                
                </td>
            </tr>
            
             ");
           }
         
           ?>
        </tbody>
        </table>
        </div>
        <a style="margin-left: 130px; width:100px;" href='shop1.php' class='btn btn-primary btn-sm'>Back</a>
        <a href='checkout.php' style="margin-left: 130px; width:100px;" class='btn btn-success btn-sm'>Checkout </a>
        </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click','#add',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'addToCart2.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });
    </script>
    <style>
       .d{
        display: none;
    
        }
     @media screen and (max-width:764px){
    .main{
        display: none;
    
        }
        .d{
        display: block !important;
    
        }
    }
    </style>
</html>