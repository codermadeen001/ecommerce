<?php
session_start();
$userName = $_POST["userName"];
$password = $_POST["password"];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}


$validating= "SELECT*FROM admn WHERE userName='$userName' && password='$password'" ;
$result1=$conn->query($validating);
if($result1->num_rows==1){
   $_SESSION['userName']=$userName;
   $_SESSION['privilegde']=1;
   echo("success");
   //echo json_encode(array("status"=>"success"));
}else{
    echo("Sorry invalid credentials");
    //echo json_encode(array("status"=>"error"));
}

$conn->close();
exit;
