<?php
session_start();
if(!isset($_SESSION['userName'])){
    header("Location:login.html");
    exit();
}
//if(!isset($_SESSION['userName'])){
    //header("Location:login.html");
   // exit();
//}

$userName=$_SESSION['userName'];
if($_SESSION['privilegde']===1){
    $userName='Admn '.$userName;
    header("Location:logout.php");
    exit();
}

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass='';

$conn=new mysqli($hostname,$username, $pass, $database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}


$sql1= "SELECT*FROM login WHERE userName='$userName'" ;
$result1=$conn->query($sql1);
$row1=$result1->fetch_assoc();
$contact=$row1["contact"];
$email=$row1["email"];
$name=$row1["name"];
$contact="254".$contact;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="checkout.css">
     <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="nav">
        <div class="logo">
            <img src="photos\IMG-20240222-WA0003.jpg">
            <h3>Cents` Online Shoppers</h3>
        </div>
        <div class="menu">
            <button type="button"id="btn" value="" onclick="fun()">Menu</button>
            <ul class="menuitems" id="menuitems">
                <li ><a href="index.php">Home</a></li>
                <li><a href="shop1.php">Shop</a></li>
                <li  class="active" ><a href="checkout.php">Checkout</a><ul><li><a href="logout.php">logout</a></li></ul></li>
            </ul>
        </div>
    </div>
    <div class="main">

        <div class="container1">
        <div class="container mv-5">
        <h2><?php echo ("      ".$userName."`s cart");?></h2>
        <table class="table">
        <thead>
            <tr>
                <td>Image</td>
                <td>Name</td>
                <td>Description</td>
                <td>Quantity</td>
                <td>Price</td>
                <td>Action</td>
            </tr>
        </thead>

        <tbody>
            <?php
            $sql1= "SELECT*FROM cart WHERE userName='$userName'";
            $result1=$conn->query($sql1);
            if($result1->num_rows<1){
               echo'Cart is Empty!';
               
          }  

          $amount=0;
          while ($row=$result1->fetch_assoc()){
             echo("
             <tr>
             <td><img style='border-radius: 100%; width: 80px; height: 80px;' src='data:image/jpeg;base64," . base64_encode($row['productImage']) . "'></td>
                <td>$row[productName]</td>
                <td>$row[productDes]</td>
                <td>$row[productQuantity]</td>
                <td>$row[productPrice]</td>
                <td>
                    <a style='margin:5px; width:100px;'id='edit' href='checkout_edit.php?id=$row[id]' class='btn btn-primary btn-sm'>Edit</a>
                    <a style='margin:5px; width:100px;' id='del' href='checkout_del.php?id=$row[id]' class='btn btn-danger btn-sm'>Delete</a>
                </td>
            </tr>
            
            ");
            $amount=$amount+$row['productPrice'];
         }
         $_SESSION['amount']=$amount;

 ?>
          </tbody>
        </table>
        </div>
    

        </div>
    
        <div class="container2">
            <div class="innerContainer">
                <form action="pay.php" method="post">
                  <input type="hidden" name="amount" value="<?php echo$amount?>">
                  <input type="hidden" name="userName" value="<?php echo$userName?>">

                    <h3>Checkout Ksh <b class="amount"><?php echo$amount?>/=</b></h3>
                    <p>Name</p>
                    <h2 class="txt"><?php echo$name?></h2>
                    <p>Email</p>
                    <h2 class="txt"><?php echo$email?></h2>
                    <input type="hidden" name="email" id="" required value="<?php echo$email?>">
                    <p>Contact</p>
                    <input type="number" name="contact" id="" required value="<?php echo$contact?>">
                    <p>Pin Location</p>
                    <input type="text" name="adress" id="" required><br>
                    <label for="" class="btn">
                    <button class="submit"type="submit" id="popupButton2">Place Order</button>
                    <a href="logout.php"><button type="submit"  class="button">Logout</button></a>
                    </label>
                </form>
            </div>
        </div>
        
        <div class="container3">
               <a href="shop1.php"><button type="button"  class="button">Shop Now</button></a>
                <a href="logout.php"><button type="button" class="button">Logout</button></a>
        </div>
        
</div>
    
</body>
<script src="shop.js"></script>
<style>
    form input{
    font-size: 20px;
    padding-left: 20px;
}
    form p{
    color: #fff;
    font-size: 20px;
    padding: 0px 0px;
}
    form h2{
    padding: 13px 0;
    font-size: 15px !important;
    margin-bottom: 0px !important;
}



</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click','#del',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'checkout_del.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });



    $(document).ready(function() {
       $("#popupButton2").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'pay.php',
               method: 'POST',
               data: {userName:$("input[name='userName']").val(), amount:$("input[name='amount']").val(), contact:$("input[name='contact']").val(), adress:$("input[name='adress']").val(), email:$("input[name='email']").val()},
               
               success: function (result) {
                     alert(result);
                }

             

           });
       });
   });







    </script>

</html>



