

<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"]=="GET"){

    if(!isset($_GET['id'])){
        //echo('id not Set');
        exit();
    }
    $id=$_GET['id'];
    if($id===NULL){
        echo('id not Set');
        exit();
    }

        
    $sql1="SELECT*FROM cart WHERE id='$id'";
    $result1=$conn->query($sql1);
    if($result1->num_rows<1){
       //header('location:checkout.php');
        exit();
    }

     $row1=$result1->fetch_assoc();
     $productName=$row1['productName'];
     $productDes=$row1['productDes'];
     $productPrice=$row1['productPrice'];
     $productQuantity=$row1['productQuantity'];
     $productId=$row1['productId'];
    $productImage=$row1['productImage'];

    $productQuantityInitial=$productQuantity;
    $quantity= $productQuantityInitial;




    $sql2= "SELECT*FROM products WHERE productId='$productId'" ;
    $result2=$conn->query($sql2);
    $row2=$result2->fetch_assoc();
    $amount=$row2['productPrice'];

}else{
     //post, update data   
        $id=$_POST['id'];
        $productId=$_POST['productId'];
        $productQuantityInitial=$_POST['productQuantityInitial'];
        $productQuantity=$_POST['productQuantity'];
        $productName=$_POST['productName'];
        if($productQuantity==0){
            echo' product Quantity can`t be 0';
            
            exit();
        }


        if($productQuantity>$productQuantityInitial){
            $quantity=$productQuantity-$productQuantityInitial;//more + to cart but less to products(sub from products)

            $sql2= "SELECT*FROM products WHERE productId='$productId'" ;
            $result2=$conn->query($sql2);
            $row2=$result2->fetch_assoc();
            $productQuantityFromPoducts=$row2['productQuantity'];
            $NewproductQuantityFromPoducts=$productQuantityFromPoducts-$quantity;
            $ProductPrice=$row2['productPrice'];
            $ProductPrice=$ProductPrice*$productQuantity;
    


            if($productQuantityFromPoducts<$quantity){
                echo($productName." is out of stoke to accommodate extra ".$quantity." more. Sorry");
               // $status==0;
                exit();
            }


            $sql3="UPDATE cart SET productQuantity='$productQuantity' WHERE id='$id'";
            $result3=$conn->query($sql3);
            $sql4="UPDATE cart SET ProductPrice='$ProductPrice' WHERE id='$id'";
            $result4=$conn->query($sql4);
            $sql5="UPDATE products SET productQuantity='$NewproductQuantityFromPoducts' WHERE productId='$productId'";
            $result5=$conn->query($sql5);
            if($result3&&$result4&&$result5===TRUE){
               //header('location:checkout.php');
               echo $productName.' Updated';
               exit();
            }else{
               echo' invalid query'.$connection->error;
               exit;
            }

        
    
        }else{
            $sql2= "SELECT*FROM products WHERE productId='$productId'" ;
            $result2=$conn->query($sql2);
            $row2=$result2->fetch_assoc();
            $productQuantityFromPoducts=$row2['productQuantity'];
            $ProductPrice=$row2['productPrice'];
            $ProductPrice=$ProductPrice*$productQuantity;
            $quantity=$productQuantityInitial-$productQuantity;//less + to cart but more to products(add to products)
            $NewproductQuantityFromPoducts=$productQuantityFromPoducts+$quantity;

            $sql3="UPDATE cart SET productQuantity='$productQuantity' WHERE id='$id'";
            $result3=$conn->query($sql3);
            $sql4="UPDATE cart SET ProductPrice='$ProductPrice' WHERE id='$id'";
            $result4=$conn->query($sql4);
           $sql5="UPDATE products SET productQuantity='$NewproductQuantityFromPoducts' WHERE productId='$productId'";
            $result5=$conn->query($sql5);
            if($result3&&$result4&&$result5===TRUE){
                //header('location:checkout.php');
                echo $productName.' Updated';
               exit();
            }else{
               echo' invalid query'.$connection->error;
               exit;
            }

        }

}


?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <style>
        body{
            background-color: rgb(240, 239, 243);
        }
        .container{
           margin: 50px 200px;
           width: 830px;
           height: 220px;
           background: #fff;
           border-radius: 15px;
           box-shadow: 4px 4px 30px rgb(255, 165, 0);

        }
        form{

           display: flex;
           align-items: center;
           justify-content: space-between;
        }
        h3{
         
            margin-left: 300px;
            font-size: 23px;
        }
        .image{
            margin-left:20px;
            padding-top:0px;
        }

        .cancel {
            margin-left: 50px;
        }

.submit .btn{
    color: #fff;
    font-size: 18px;
}
form input{
    width: 100px;
    height: 25px;
    border-radius: 5px;
    border: 1px solid #3333;
    outline: none;
    margin: 10px 0;
    padding-left: 20px;
    font-size: 18px;
}
form h3{
    color: #111;
    padding-top: 0px;
    font-size: 22px;
}
form p{
    color: #111;
    font-size: 20px;
    padding: 5px 0px;
}

form p input{
    width: 30px;
    height: 25px;
    margin-right: 5px;
}
.buttons{
    display:flex;
    align-items:center;
    justify-content:right;
}
    </style>

    <div class="container" >
        <h3>Edit product quantity</h3>


        <form method="POST">
            <input type="hidden" name="id" value="<?php echo$id?>">
            <input type="hidden" name="productQuantityInitial" value="<?php echo$productQuantityInitial?>">
            <input type="hidden" name="productId" value="<?php echo$productId?>">
            <input type="hidden" name="productName" value="<?php echo$productName?>">
                    <div class="image">
                        <p>Image</p>
                        <h2 class="txt"><?php 
                         echo "<img style=' border-radius: 100%; height: 80px; width: 80px;' src='data:image/jpeg;base64," . base64_encode($row1['productImage']) . " '><br>";
                        ?></h2>
                    </div>
    
                    <div class="name">
                        <p>Name</p>
                        <h2 style=' font-size:20px;' class="txt"><?php echo$productName?></h2>
                    </div>

                    <div class="description">
                        <p>Description</p>
                        <h2 style=' font-size:20px;' class="txt"><?php echo$productDes?></h2>
                    </div>

                    <div class="quantity">
                        <p>quantity</p>
                        <input type="number" id="quantity" name="productQuantity" value="<?php echo $quantity; ?>" oninput="calculateAmount()"><br><br>

                    </div>
    
                    <div class="price">
                        <p>price</p>
                        <h2><input style="color: red; outline:none; border:none; font-size:20px;" type="text" id="amount" name="amount" value="<?php echo $amount; ?>" readonly></h2>
                    </div>


          
            <div class="buttons">

                <div class="submit">
                    <button type="submit" id="popupButton2" class="btn btn-primary">Update</button>
                </div>
                <div class="cancel">
                    <a  href="checkout.php" class="btn btn-outline-primary" role="button">cancel</a>
                </div>
                
            </div>


        </form>
</body>
<script>
        // Initial calculation
        calculateAmount();

        function calculateAmount() {
            var quantity = document.getElementById('quantity').value;
            var amount = <?php echo $amount; ?> * quantity;
            document.getElementById('amount').value = amount;
        }
    </script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

$(document).ready(function() {
       $("#popupButton2").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'checkout_edit.php',
               method: 'POST',
               data: {id:$("input[name='id']").val(), productId:$("input[name='productId']").val(), 
                productName:$("input[name='productName']").val(), productQuantityInitial:$("input[name='productQuantityInitial']").val(), 
                email:$("input[name='email']").val(),userName:$("input[name='userName']").val(), amount:$("input[name='amount']").val(), 
                productQuantity:$("input[name='productQuantity']").val()},
               
               success: function (result) {
                    
                    alert(result);

                        window.location.href = 'checkout.php';
               

                     
                }
              

             

           });
       });
   });

</script>
</html>







