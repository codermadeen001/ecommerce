<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

$name='';
$userName='';
$contact='';
$email='';
$errorMessage='';
$successMessage='';

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $userName=$_POST['userName'];
    $contact=$_POST['contact'];
    $status=0;
    $password=$userName;

    do {
        if(empty($name) || empty($userName) || empty($contact) || empty($email)){
            $errorMessage='all fields required ';
            break;
        }

         //add new client to db

        $sql="INSERT INTO login(name, userName, email,contact, password, status) VALUES('$name','$userName','$email','$contact','$password','$status')";
        $msqli=$conn->query($sql);

        $to = $email;
        $subject = "Account Creation";
        $message = "This is to inform you ".$userName.", that your account for Cents` Online Shoppers \n has been created.\n".$userName." is your password";
        $headers = "From: syeundainnocent@gmail.com" . "\r\n" .
           "Reply-To: syeundainnocent@gmail.com" . "\r\n" .
           "X-Mailer: PHP/" . phpversion();
        mail($to, $subject, $message, $headers);

        if(!$msqli){
          echo('Registration is Unsuccessful');
          break;
       }

          $name='';
          $userName='';
          $contact='';
          $email='';
          $successMessage='client Added successfully';

          header('location:checkUsers.php');
          exit();

    } while (false);

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div class="container mv-5" >
        <h2>New client</h2>

        <?php 
            if(!empty($errorMessage)){
                echo("
                <div class='alert alert-warning alert-dissmissible fade show' role='alert'>
                   <strong>$errorMessage<strong>
                   <button class='btn-close' data-bs-dismiss='alert'aria-label='close' type='button'></button>
                </div>
                ");
            }
            ?> 

        <form  method="post">
            <div class="row mb-3">
                <label for="" class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-6">
                    <input name="name"  type="text" class="form-control" value="<?php echo$name?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-sm-3 col-form-label">userName</label>
                <div class="col-sm-6">
                    <input name="userName" type="text" class="form-control" value="<?php echo$userName?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-sm-3 col-form-label">contact</label>
                <div class="col-sm-6">
                    <input name="contact" type="number" class="form-control" value="<?php echo$contact?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="" class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                    <input name="email" type="email" class="form-control" value="<?php echo$email?>">
                </div>
            </div>

            <?php 
            if(!empty($successMessage)){
                echo("
                <div class='row mb-3'>
                   <div class='offset-sm-3 col-sm-6'>
                   <div class='alert alert-success alert-dissmissible fade show' role='alert'>
                   <strong>$successMessage<strong>
                   <button class='btn-close' data-bs-dismiss='alert'aria-label='close' type='button'></button>
                   </div>
                   </div>
                </div>
                ");
            }
            ?> 

            <div class="row mb-3">
                <div class="offset-sm-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a href="checkUsers.php" class="btn btn-outline-primary" role="button">cancel</a>
                </div>
            </div>


        </form>
    </div>
</body>
</html>