<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mv-5">
        <h2>List of Products</h2>
        <br>
        <table class="table">
           <thead>
           <tr>
                <td>Product Id</td>
                <td>Image</td>
                <td>Name</td>
                <td>Description</td>
                <td>Quantity</td>
                <td>Price</td>
                <td>Action</td>
            </tr>
            </thead>

            <tbody>
            <?php
            $hostname='localhost';
            $username='root';
            $database='ecommerce';
            $pass=NULL;

            $conn=new mysqli($hostname,$username, $pass,$database);
            if($conn->connect_error){
              die('Connection failed: '.$conn->connect_error);
            }

            $sql1= "SELECT*FROM products" ;
            $result1=$conn->query($sql1);
            if($result1->num_rows<1){
               echo'No products';
               
            }
            $Tamount=0;

            while ($row=$result1->fetch_assoc()){
             echo("
             <tr>
                <td>$row[productId]</td>
                <td><img style='border-radius: 100%;width: 100px; height: 100px;' src='data:image/jpeg;base64," . base64_encode($row['productImage']) . " '></td>
                <td>$row[productName]</td>
                <td>$row[productDes]</td>
                <td>$row[productQuantity]</td>
                <td>$row[productPrice]</td>
                <td>
                <a href='checkProducts_update.php?id=$row[id]' class='btn btn-primary btn-sm'>Update</a>
                <a href='checkProducts_del.php?id=$row[id]' class='btn btn-danger btn-sm' id='deleteBtn'>Delete</a>
                </td>
            </tr>
            
             ");
             $Tamount= $Tamount+$row['productPrice']*$row['productQuantity'];;
           }
           
           ?>
        </tbody>
        <h1 style="color: red; font-size: 20px;"> <?php echo "Net Value Ksh ".$Tamount."/="?></h1>
        </table>
        </div>
        <a style="margin-left: 200px;" href='admnPanel.php' class='btn btn-primary btn-sm'>admnPanel</a>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click','#deleteBtn',function(event) {
            event.preventDefault(); // Prevent form submission
            var href = $(this).attr("href");
            var id = href.split("=")[1];
            
            // AJAX request to login.php
            $.ajax({
                type: 'GET',
                url: 'checkProducts_del.php',
                data: {id: id},
                //dataType:'json',
                success: function(response) {
                    //if (response.status === "suspend"){
                        alert(response); 
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('error occured'+ error);
                    } 
                       
               
            });
        });
    });
    </script>
</html>