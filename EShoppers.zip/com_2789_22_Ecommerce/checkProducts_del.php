<?php
if(isset($_GET["id"])){  
$id=$_GET["id"];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}

$sql1="SELECT*FROM products WHERE id='$id'";
$result1=$conn->query($sql1);
$row1=$result1->fetch_assoc();
$ProductId=$row1['productId'];
$productName=$row1['productName'];


$sql3= "DELETE FROM products WHERE id='$id'" ;
$result3=$conn->query($sql3);


$sql4= "DELETE FROM cart WHERE productId='$ProductId'" ;
$result4=$conn->query($sql4);



echo($productName.' is deleated ');

exit();

}else{
    echo 'id not set';
}



