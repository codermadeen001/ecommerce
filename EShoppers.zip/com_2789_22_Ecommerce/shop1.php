<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="shop.css">
    <title>Document</title>
</head>

<body>
<?php 
session_start();
if(isset($_SESSION['userName'])&& $_SESSION['privilegde']==2){
    $userName=$_SESSION['userName']; 
    $sql1="SELECT*FROM cart WHERE userName='$userName'";
    $result1=$conn->query($sql1);
    $amount=0;
    $quantity=0;
    if($result1->num_rows>0){
        while ($row=$result1->fetch_assoc()){
              $row['productQuantity'];
              $row['productPrice'];
          $quantity=$quantity+$row['productQuantity'];
          $amount=$amount+$row['productPrice'];
    }
}
if($amount>0){
    echo(" 
    <a href='checkout.php'> <div style='border-radius: 100%; cursor:pointer; position: fixed; z-index: 9999;top: 40%;left: 77%;transform: translate(-50%, -50%);
         background-color: lightgreen; padding: 35px; width: 120px; height: 120px;'>
             <p  style='font-weight: bold; color: #111;font-size: 20px; '>$quantity </p>
             <p style='color: rgb(255, 165, 0);font-size: 20px; padding-bottom:30px !important; font-weight: bold;'>$amount/=</p>
         </div></a>
         
         " );
 }

   }

?>
    <div class="nav">
        <div class="logo">
            <img src="photos\IMG-20240222-WA0003.jpg">
            <h3>Cents` Online Shoppers</h3>
        </div>
        <div class="menu">
            <button type="button"id="btn" value="" onclick="fun()">Menu</button>
            <ul class="menuitems" id="menuitems">
                <li ><a href="index.php">Home</a></li>
                <li class="active"><a href="shop1.php">Shop</a><ul><li><a href="shop.php">Shop More</a></li></ul></li>
                <li ><a href="checkout.php">Checkout</a></li>
            </ul>
        </div>
    </div>

    <section class="container">
        <form action="" method="post" id="form">
            <i class="fas fa-search"></i>
            <input style="font-size: 18px;" type="text" name="" id="search-item" placeholder="search products" onkeyup="search()">
        </form>
        
        <div class="product-list" id="product-list">
            <div class="product">
                <img src="photos/IMG-20240225-WA0013.jpg" alt="img">
                <div class="p-details">
                    <h1>Watch </h1>
                    <h3>Wrist Watch</h3>
                    <h3>Ksh 1, 200/=</h3>
                      <form action="addToCart1.php" method="post" id="myForm">
                        <input type="hidden" name="productId" value="1">
                        <button class="submit" id="popupButton1" type="submit">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0009.jpg" alt="img">
                <div class="p-details">
                    <h1>Iron Box </h1>
                    <h3>Sathiya Electric Iron Box</h3>
                    <h3>Ksh 1, 000/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" id="productId" value="2">
                        <button class="submit" type="submit" id="popupButton2">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0005.jpg" alt="img">
                <div class="p-details">
                    <h1>Bike </h1>
                    <h3>Mountain Bike</h3>
                    <h3>Ksh 15, 000/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="3">
                        <button class="submit" type="submit" id="popupButton3">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0017.jpg" alt="img">
                <div class="p-details">
                    <h1>Jacket </h1>
                    <h3>    Mens` Jacket</h3>
                    <h3>Ksh 2, 000/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="4">
                        <button class="submit" type="submit" id="popupButton4">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0015.jpg" alt="img">
                <div class="p-details">
                    <h1>Chair </h1>
                    <h3>Rocking Chair</h3>
                    <h3>Ksh 3, 500/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="5">
                        <button class="submit" type="submit" id="popupButton5">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0012.jpg" alt="img">
                <div class="p-details">
                    <h1>Tv </h1>
                    <h3>40 inch  Vision Plus Smart TV</h3>
                    <h3>Ksh 30, 000/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="6">
                        <button class="submit" type="submit" id="popupButton6">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0006.jpg" alt="img">
                <div class="p-details">
                    <h1>Boots </h1>
                    <h3>Converse Shoes</h3>
                    <h3>Ksh 1, 700/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="7">
                        <button class="submit" type="submit" id="popupButton7">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0001.jpg" alt="img">
                <div class="p-details">
                    <h1>Cup </h1>
                    <h3>Laravel Developers` Mug</h3>
                    <h3>Ksh 800/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="8">
                        <button class="submit" type="submit" id="popupButton8">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0004.jpg" alt="img">
                <div class="p-details">
                    <h1>Ball </h1>
                    <h3>FootBall</h3>
                    <h3>Ksh 1, 400/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="9">
                        <button class="submit" type="submit" id="popupButton9">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0008.jpg" alt="img">
                <div class="p-details">
                    <h1>TeddyBear </h1>
                    <h3>For Children</h3>
                    <h3>Ksh 900/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="10">
                        <button class="submit" type="submit" id="popupButton10">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0002.jpg" alt="img">
                <div class="p-details">
                    <h1>Globe </h1>
                    <h3>World globe for Geography/ers</h3>
                    <h3>Ksh 500/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="11">
                        <button class="submit" type="submit" id="popupButton11">Add to cart</button>
                    </form>
                </div>
            </div>

            <div class="product">
                <img src="photos/IMG-20240225-WA0016.jpg" alt="img">
                <div class="p-details">
                    <h1>Lotion </h1>
                    <h3>Nice and Lovely Cocoa Butter</h3>
                    <h3>Ksh 300/=</h3>
                      <form action="addToCart1.php" method="post">
                        <input type="hidden" name="productId" value="12">
                        <button class="submit" type="submit"id="popupButton12" >Add to cart</button>
                    </form>
                </div>
            </div>

            
         <div class="further">
            <button><a href="shop.php">More Products</a></button>
         </div>
         
        </div>
    </section>
</body>
<script src="shop.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>


$(document).ready(function() {
       $("#popupButton1").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:$("input[name='productId']").val()},
               
               success: function (result) {
                   location.reload();
                   alert(result);
               }
           });
       });
   });




   $(document).ready(function() {
       $("#popupButton2").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:2},
               success: function (result) {
                location.reload();
                   alert(result);
               }
           });
       });
   });

   $(document).ready(function() {
       $("#popupButton3").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:3},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });




   $(document).ready(function() {
       $("#popupButton4").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:4},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });



   $(document).ready(function() {
       $("#popupButton5").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:5},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });

   $(document).ready(function() {
       $("#popupButton6").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:6},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });




   $(document).ready(function() {
       $("#popupButton7").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:7},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });



   $(document).ready(function() {
       $("#popupButton8").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:8},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });

   $(document).ready(function() {
       $("#popupButton9").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:9},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });




   $(document).ready(function() {
       $("#popupButton10").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:10},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });





   $(document).ready(function() {
       $("#popupButton11").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:11},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });

   $(document).ready(function() {
       $("#popupButton12").click(function (e) {
           e.preventDefault();
           $.ajax({
               url: 'addToCart1.php',
               method: 'POST',
               data: {productId:12},
               
               success: function (result) {
                   alert(result);
                   location.reload();
               }
           });
       });
   });


</script>
</html>