<?php
$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
        die('Connection failed: '.$conn->connect_error);
}


if($_SERVER["REQUEST_METHOD"]=="GET"){

    if(!isset($_GET['id'])){
        echo('id not provided');
        exit();
    }
    $id=$_GET['id'];

    $sql1= "SELECT*FROM login WHERE id='$id'" ;
    $result1=$conn->query($sql1);
    $row=$result1->fetch_assoc();
    $status=$row['status'];
    $userName=$row['userName'];
    $email=$row['email'];
 
    if($status==0){
     echo($userName. ' is not suspended');
     exit();
    }else {
        $sql2="UPDATE login SET status=0 WHERE id='$id'";
        $result2=$conn->query($sql2);
        echo($userName. ' is unsuspended');

        $to = $email;
        $subject = "Account UnSuspension";
        $message = "This is to inform you ".$userName.", that your account for Cents` Online Shoppers \n has been Unsuspended.";
        $headers = "From: syeundainnocent@gmail.com" . "\r\n" .
           "Reply-To: syeundainnocent@gmail.com" . "\r\n" .
           "X-Mailer: PHP/" . phpversion();
        mail($to, $subject, $message, $headers);

    }

}
?>
