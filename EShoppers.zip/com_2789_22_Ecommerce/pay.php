<?php
$amount=$_POST['amount'];
$userName=$_POST['userName'];
$contact=$_POST["contact"];
$address=$_POST["adress"];
$email=$_POST["email"];

if($amount==0){
    echo('Can`t pay Ksh: '.$amount);
    exit();
}

$consumerKey='GEbw20blouHEWfGCTGcGahrTZkJ1yQcG';
$consumerSecret='6FwtamyAnR5hSMPb';
$passkey='bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919'; 
$shortcode='174379';

// Function to initiate STK push
function initiateStkPush() {
    global $consumerKey, $consumerSecret, $shortcode, $passkey;

    $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, ['Authorization: Basic ' . base64_encode($consumerKey . ':' . $consumerSecret)]);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $token = json_decode(curl_exec($curl));
    curl_close($curl);

    $access_token = $token->access_token;

    $timestamp = date('YmdHis');
    $password = base64_encode($shortcode . $passkey . $timestamp);

    $stk_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $stk_url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'Authorization:Bearer ' . $access_token));
    $curl_post_data = array(
        'BusinessShortCode' => $shortcode,
        'Password' => $password,
        'Timestamp' => $timestamp,
        'TransactionType' => 'CustomerPayBillOnline',
        'Amount' =>$_POST['amount'], // Example amount
        'PartyA' =>$_POST["contact"], // User phone number
        'PartyB' => $shortcode,
        'PhoneNumber' =>$_POST["contact"], // User phone number
        'CallBackURL' => 'https://19cc-41-89-160-14.ngrok-free.app/test/callback.php', // Your callback URL
        'AccountReference' => 'Cents Online Shoppers',
        'TransactionDesc' => 'Cents Online Shoppers'
    );

    $data_string = json_encode($curl_post_data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
    $curl_response = curl_exec($curl);
    return $curl_response;
}

// Call the function to initiate STK push
$response = initiateStkPush();
//echo $response; // Handle the response as needed

$callback_data = json_decode($response);
echo('Transaction was successful');
/* Check if the transaction was unsuccessful
if ($callback_data->Body->stkCallback->ResultCode && $callback_data->Body->stkCallback->ResultCode == 0) {
    // Transaction was unsuccessful
    // Handle the unsuccessful transaction here
    // For example, log the transaction details or notify the user
    echo('success purchase');
    $to = $email;
    $subject = "Successful Purchase";
    $message = "This is to inform you ".$userName.", that your have shopped for goods worth ".$amount."\n
    Goods will be delivered within next 1hour\n
    Thanks for shoppin with Cents` Online Shoppers.\n";
    $headers = "From: syeundainnocent@gmail.com" . "\r\n" .
       "Reply-To: syeundainnocent@gmail.com" . "\r\n" .
       "X-Mailer: PHP/" . phpversion();
    mail($to, $subject, $message, $headers);
    // You can access additional details such as $callback_data->Body->stkCallback->ResultDesc for error description
} else {
    // Transaction was successful
    // You can handle successful transactions here  https://www.naijaprey.com/tag/animation-movies-download-02/
    echo('Failed purchase');
}*/
?>




