<?php
session_start();
$userName=$_POST["userName"];
$password=$_POST["password"];

$hostname='localhost';
$username='root';
$database='ecommerce';
$pass=NULL;

$conn=new mysqli($hostname,$username, $pass,$database);

if($conn->connect_error){
    die('Connection failed: '.$conn->connect_error);
}


$validating= "SELECT*FROM login WHERE userName='$userName' && password='$password'" ;
$result1=$conn->query($validating);
if($result1->num_rows==1){

    $supensin_check= "SELECT status from login WHERE username='$userName' ";
    $result2=$conn->query($supensin_check);
    $row=$result2->fetch_assoc();
    if($row["status"]==1){
       // echo("Sorry ".$userName." you are suspended ");
       echo "suspend";
       //echo json_encode(array("status"=>"suspend"));
        exit();
    }
   //header("Location:index.html");
   $_SESSION['userName']=$userName;
   $_SESSION['privilegde']=2;
   echo "success";
   //echo json_encode(array("status"=>"success"));
}else{
    echo("Sorry invalid credentials");
   //echo json_encode(array("status"=>"error"));
}

$conn->close();
exit;


